``even``
========

``even`` returns ``true`` if the given number is even:

.. code-block:: jinja

    {{ var is even }}

.. seealso:: :doc:`odd<../tests/odd>`
